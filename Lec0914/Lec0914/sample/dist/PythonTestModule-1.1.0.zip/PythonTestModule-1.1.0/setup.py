from distutils.core import setup

setup(
    name = "PythonTestModule",
    version = "1.1.0",
    py_modules=["printData"],
    author = "sgygayoung",
    author_email = "gayounggirl@naver.com",
    url = "http://www.github.com/sgygayoung",
    description = "Test Module",
    )